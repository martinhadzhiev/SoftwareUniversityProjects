﻿public interface ICar
{
    string Model { get; }

    string Color { get; }

    string Stop();

    string Start();
}