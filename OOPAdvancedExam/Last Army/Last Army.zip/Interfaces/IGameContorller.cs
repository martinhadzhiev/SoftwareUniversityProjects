﻿public interface IGameContorller
{

}