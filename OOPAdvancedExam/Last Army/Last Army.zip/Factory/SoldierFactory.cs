﻿public class SoldierFactory : ISoldierFactory
{
    public ISoldier CreateSoldier(string soldierTypeName, string name,
        int age, double experience, double endurance)
    {
        throw new System.NotImplementedException();
    }
}