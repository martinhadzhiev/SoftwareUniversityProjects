﻿namespace _05.MordorsCrueltyPlan.Foods
{
    public class Melon : Food
    {
        public Melon()
            :base(1)
        {
            
        }
    }
}
