﻿namespace _05.MordorsCrueltyPlan.Foods
{
    public class Mushrooms : Food
    {
        public Mushrooms()
            :base(-10)
        {
            
        }
    }
}
