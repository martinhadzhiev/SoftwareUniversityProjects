﻿namespace _05.MordorsCrueltyPlan.Foods
{
    public class Lembas : Food
    {
        public Lembas()
            :base(3)
        {
            
        }
    }
}
