﻿namespace _05.MordorsCrueltyPlan.Foods
{
    public class Junk : Food
    {
        public Junk()
            :base(-1)
        {
            
        }
    }
}
