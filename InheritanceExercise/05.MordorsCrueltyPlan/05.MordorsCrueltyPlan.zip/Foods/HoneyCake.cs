﻿namespace _05.MordorsCrueltyPlan.Foods
{
    public class HoneyCake : Food
    {
        public HoneyCake()
            :base(5)
        {
            
        }
    }
}
