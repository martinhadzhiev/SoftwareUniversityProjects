﻿namespace _05.MordorsCrueltyPlan.Moods
{
    public class Angry : Mood
    {
        public Angry()
            :base("Angry")
        {
            
        }
    }
}
