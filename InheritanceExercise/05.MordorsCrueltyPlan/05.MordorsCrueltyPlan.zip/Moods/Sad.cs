﻿namespace _05.MordorsCrueltyPlan.Moods
{
    public class Sad : Mood
    {
        public Sad()
            :base("Sad")
        {
            
        }
    }
}
