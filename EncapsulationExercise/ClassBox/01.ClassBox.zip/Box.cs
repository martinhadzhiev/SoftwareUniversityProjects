﻿using System;

public class Box
{
    private double lenght;
    private double width;
    private double height;

    public Box(double lenght, double width, double height)
    {
        this.lenght = lenght;
        this.width = width;
        this.height = height;
    }

    public void GetAreaAndVolume()
    {
        var l = this.lenght;
        var w = this.width;
        var h = this.height;

        Console.WriteLine($"Surface Area - {(2 * l * w) + (2 * l * h) + (2 * w * h):F2}");
        Console.WriteLine($"Lateral Surface Area - {(2 * l * h) + (2 * w * h):F2}");
        Console.WriteLine($"Volume - {l * w * h:F2}");
    }
}