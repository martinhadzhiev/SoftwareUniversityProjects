﻿public interface IMyList<T> : IAddRemoveCollection<T>
{

}