﻿public class Citizen : ICheckable
{
    private string Name { get; set; }
    private int Age { get; set; }
    public string Id { get; private set; }

    public Citizen(string name, int age, string id)
    {
        this.Name = name;
        this.Age = age;
        this.Id = id;
    }
}