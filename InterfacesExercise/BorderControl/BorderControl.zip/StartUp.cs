﻿using System;
using System.Collections;
using System.Collections.Generic;

class StartUp
{
    static void Main()
    {
        ICollection<ICheckable> objectsToCheck = new List<ICheckable>();

        var command = Console.ReadLine();

        while (command != "End")
        {
            var cmdArgs = command.Trim().Split();

            if (cmdArgs.Length == 2)
            {
                objectsToCheck.Add(new Robot(cmdArgs[0],cmdArgs[1]));
            }
            else
            {
                objectsToCheck.Add(new Citizen(cmdArgs[0],int.Parse(cmdArgs[1]),cmdArgs[2]));
            }

            command = Console.ReadLine();
        }

        var fakeId = Console.ReadLine();

        foreach (var checkable in objectsToCheck)
        {
            if (checkable.Id.EndsWith(fakeId))
            {
                Console.WriteLine(checkable.Id);
            }
        }
    }
}