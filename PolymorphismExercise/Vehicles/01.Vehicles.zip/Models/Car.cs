﻿namespace Vehicles.Models
{
    using System;

    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {
            this.FuelConsumption += 0.9;
        }

        public override void DriveVehicle(double km)
        {
            if (km * this.FuelConsumption <= this.FuelQuantity)
            {
                Console.WriteLine($"Car travelled {km} km");
                this.FuelQuantity -= km * this.FuelConsumption;
            }
            else
            {
                Console.WriteLine($"Car needs refueling");
            }
        }

        public override void RefuelVehicle(double fuel)
        {
            this.FuelQuantity += fuel;
        }
    }
}
