﻿namespace Vehicles.Models
{
    using System;

    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {
            this.FuelConsumption += 1.6;
        }

        public override void DriveVehicle(double km)
        {
            if (km * this.FuelConsumption <= this.FuelQuantity)
            {
                Console.WriteLine($"Truck travelled {km} km");
                this.FuelQuantity -= km * this.FuelConsumption;
            }
            else
            {
                Console.WriteLine($"Truck needs refueling");
            }
        }

        public override void RefuelVehicle(double fuel)
        {
            this.FuelQuantity += fuel * 0.95;
        }
    }
}
