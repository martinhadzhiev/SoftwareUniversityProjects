﻿namespace WildFarm.Animals
{
    public abstract class Felime : Mammal
    {
        public Felime(string type, string name, double weight, string livingRegion)
            : base(type, name, weight, livingRegion)
        {
        }
    }
}
