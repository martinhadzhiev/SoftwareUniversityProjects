﻿namespace CutomList
{
    using System;
    using System.Linq;

    public class Sorter<T> where T : IComparable
    {
        public static MyList<T> Sort(MyList<T> customList)
        {
            MyList<T> sortedList = new MyList<T>();

            customList.Data.OrderBy(a => a).ToList().ForEach(a => sortedList.Add(a));

            return sortedList;
        }
    }
}
