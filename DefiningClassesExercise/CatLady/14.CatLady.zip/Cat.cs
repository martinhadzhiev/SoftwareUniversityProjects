﻿namespace CatLady
{
    public class Cat
    {
        public string name;
    }
}
