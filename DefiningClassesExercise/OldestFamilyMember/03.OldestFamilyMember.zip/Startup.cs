﻿using System;
using System.Reflection;

class Startup
{
    static void Main()
    {
        var n = int.Parse(Console.ReadLine());

        var family = new Family();

        for (int i = 0; i < n; i++)
        {
            var line = Console.ReadLine().Split();
            var name = line[0];
            var age = int.Parse(line[1]);

            Person p = new Person();
            p.name = name;
            p.age = age;

            family.AddMember(p);
        }

        Console.WriteLine($"{family.GetOldestMember().name} {family.GetOldestMember().age}");

        MethodInfo oldestMemberMethod = typeof(Family).GetMethod("GetOldestMember");
        MethodInfo addMemberMethod = typeof(Family).GetMethod("AddMember");
        if (oldestMemberMethod == null || addMemberMethod == null)
        {
            throw new Exception();
        }
    }
}

