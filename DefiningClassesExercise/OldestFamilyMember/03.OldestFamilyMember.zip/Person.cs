﻿public class Person
{
    public string name;
    public int age;
}