﻿public class Engine
{
    public int speed;
    public int power;
}