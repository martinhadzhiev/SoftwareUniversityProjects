﻿public class Cargo
{
    public int weight;
    public string type;
}