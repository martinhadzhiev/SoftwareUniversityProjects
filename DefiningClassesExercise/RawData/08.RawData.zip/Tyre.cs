﻿public class Tyre
{
    public double pressure;
    public int age;
}