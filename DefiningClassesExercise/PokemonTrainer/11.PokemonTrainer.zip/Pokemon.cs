﻿namespace PokemonTrainer
{
    public class Pokemon
    {
        public string name;
        public string element;
        public double health;

        public Pokemon(string name , string element , double health)
        {
            this.name = name;
            this.element = element;
            this.health = health;
        }
    }
}
