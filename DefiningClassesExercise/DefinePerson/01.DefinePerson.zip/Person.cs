﻿public class Person
{
    public string name;
    public string age;
}

