﻿namespace Google
{
    public class Company
    {
        public string name;
        public string department;
        public decimal salary;
    }
}
