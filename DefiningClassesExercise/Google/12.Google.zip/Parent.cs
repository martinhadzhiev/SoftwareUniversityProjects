﻿namespace Google
{
    public class Parent
    {
        public string name;
        public string birthday;
    }
}
