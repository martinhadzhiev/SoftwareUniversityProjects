﻿namespace Google
{
    public class Car
    {
        public string model;
        public string speed;
    }
}
