﻿namespace Google
{
    public class Pokemon
    {
        public string name;
        public string type;
    }
}
