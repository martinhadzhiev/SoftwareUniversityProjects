﻿namespace Google
{
    public class Child
    {
        public string name;
        public string birthday;
    }
}
