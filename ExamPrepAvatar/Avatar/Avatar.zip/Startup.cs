﻿public class Startup
{
    static void Main()
    {
        InputParser parser = new InputParser();
        parser.Run();
    }
}