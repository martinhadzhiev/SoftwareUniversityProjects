﻿using NUnit.Framework;

[TestFixture]
public class DummyTests
{
    [Test]
    public void TestMethod()
    {
        // TODO: Add your test code here
        Assert.Pass("Your first passing test");
    }
}