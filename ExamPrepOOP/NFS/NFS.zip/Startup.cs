﻿public class Startup
{
    static void Main()
    {
        InputParser inputParser = new InputParser();
        inputParser.Read();
    }
}
