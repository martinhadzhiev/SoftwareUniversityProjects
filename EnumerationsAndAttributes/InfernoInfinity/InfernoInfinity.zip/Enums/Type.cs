﻿namespace InfernoInfinity.Enums
{
    public enum Type
    {
        Axe = 4,
        Sword = 3,
        Knife = 2
    }
}
